package com.alianhome.getchannel;

import java.io.IOException;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import com.unity3d.player.UnityPlayer;
import com.unity3d.player.UnityPlayerActivity;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.text.TextUtils;
import android.util.Log;

public class MainActivity extends UnityPlayerActivity {
	public static String GetChannel(final String key_name) {

		String channel = null;
		channel = GetChannelFromApk(key_name);
		if (!TextUtils.isEmpty(channel)) {
			return channel;
		}

		PackageManager packageManager = UnityPlayer.currentActivity
				.getPackageManager();
		String pkg = UnityPlayer.currentActivity.getPackageName();
		try {

			ApplicationInfo applicationInfo = packageManager
					.getApplicationInfo(pkg, PackageManager.GET_META_DATA);
			channel = applicationInfo.metaData.getString(key_name);

		} catch (Exception e) {
			Log.e("com.alianhome.getchannel.MainActivity", e.getMessage());
		}
		return channel;
	}

	/**
	 *  ��APK ���ж�ȡ�ļ�
	 * @param key_name Ҫ���ҵİ����ļ���
	 * @return ����ҵ�,�򷵻س���key_name֮�������
	 */
	public static String GetChannelFromApk(String key_name) {

		String channel = null;
		ApplicationInfo applicationInfo = UnityPlayer.currentActivity
				.getApplicationInfo();
		String sourceDir = applicationInfo.sourceDir;
		ZipFile zipFile = null;
		String searchString = key_name;
		try {
			zipFile = new ZipFile(sourceDir);
			Enumeration<?> entries = zipFile.entries();
			while (entries.hasMoreElements()) {
				ZipEntry entry = (ZipEntry) entries.nextElement();
				String entryName = entry.getName();
				if (entryName.contains(searchString)) {
					int index = entryName.lastIndexOf(searchString);
					channel = entryName
							.substring(index + searchString.length());
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (zipFile != null) {
				try {
					zipFile.close();
				} catch (IOException e) {

					e.printStackTrace();
				}
			}
		}
		return channel;
	}
}

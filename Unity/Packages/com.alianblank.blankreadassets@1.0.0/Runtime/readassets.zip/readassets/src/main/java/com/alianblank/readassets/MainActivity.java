package com.alianblank.readassets;

import android.content.res.AssetManager;

import com.unity3d.player.UnityPlayer;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;


public class MainActivity {
    private static AssetManager assetManager;
    //    private static String TAG = "readFile";
    private static HashMap<String, Boolean> mFileTable;

    /**
     * 判断文件是否存在
     *
     * @param path 文件路径
     * @return 返回存在或不存在
     * @throws IOException
     */
    public static boolean isFileExists(String path) throws IOException {
        guard();
        if (mFileTable.containsKey(path))
            return true;
        InputStream input = null;
        try {
            input = assetManager.open(path);
            mFileTable.put(path, true);
            input.close();
            return true;
        } catch (Exception e) {
            if (input != null) {
                input.close();
            }
            return false;
        }
    }

    private static void guard() {
        if (assetManager == null) {
            assetManager = UnityPlayer.currentActivity.getApplication().getAssets();
        }
        if (mFileTable == null) {
            mFileTable = new HashMap<>(128);
        }
    }

    /**
     * 读取assets 目录下的文件
     *
     * @param path 读取完整的路径
     * @return 返回读取后的数组
     */
    public static byte[] readFile(final String path) throws IOException {
        byte[] buffer = null;
        guard();
        InputStream inputStream = null;
        try {
            inputStream = assetManager.open(path);

            int length = inputStream.available();
            buffer = new byte[length];
            int res = inputStream.read(buffer);
            inputStream.close();
            mFileTable.put(path, true);
        } catch (IOException e) {
            if (inputStream != null) {
                inputStream.close();
            }
            e.printStackTrace();
        }
        return buffer;
    }
}

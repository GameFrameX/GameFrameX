---@class CS.FairyEditor.I18nSettings.LanguageFile
---@field public name string
---@field public path string
---@field public modificationDate CS.System.DateTime

---@type CS.FairyEditor.I18nSettings.LanguageFile
CS.FairyEditor.I18nSettings.LanguageFile = { }
---@return CS.FairyEditor.I18nSettings.LanguageFile
function CS.FairyEditor.I18nSettings.LanguageFile.New() end
return CS.FairyEditor.I18nSettings.LanguageFile

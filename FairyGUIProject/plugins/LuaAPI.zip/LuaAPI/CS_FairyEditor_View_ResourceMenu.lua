---@class CS.FairyEditor.View.ResourceMenu
---@field public realMenu CS.FairyEditor.Component.IMenu
---@field public targetItems CS.System.Collections.Generic.List_CS.FairyEditor.FPackageItem

---@type CS.FairyEditor.View.ResourceMenu
CS.FairyEditor.View.ResourceMenu = { }
---@return CS.FairyEditor.View.ResourceMenu
function CS.FairyEditor.View.ResourceMenu.New() end
function CS.FairyEditor.View.ResourceMenu:Show() end
return CS.FairyEditor.View.ResourceMenu

---@class CS.FairyEditor.View.DocCamera : CS.UnityEngine.MonoBehaviour
---@field public cachedTransform CS.UnityEngine.Transform
---@field public cachedCamera CS.UnityEngine.Camera
---@field public owner CS.FairyGUI.GComponent

---@type CS.FairyEditor.View.DocCamera
CS.FairyEditor.View.DocCamera = { }
---@return CS.FairyEditor.View.DocCamera
function CS.FairyEditor.View.DocCamera.New() end
return CS.FairyEditor.View.DocCamera

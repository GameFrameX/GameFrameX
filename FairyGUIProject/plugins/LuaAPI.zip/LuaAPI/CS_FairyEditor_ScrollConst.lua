---@class CS.FairyEditor.ScrollConst
---@field public HORIZONTAL string
---@field public VERTICAL string
---@field public BOTH string

---@type CS.FairyEditor.ScrollConst
CS.FairyEditor.ScrollConst = { }

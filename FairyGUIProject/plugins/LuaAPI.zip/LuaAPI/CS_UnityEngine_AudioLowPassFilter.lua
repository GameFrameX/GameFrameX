---@class CS.UnityEngine.AudioLowPassFilter : CS.UnityEngine.Behaviour
---@field public cutoffFrequency number
---@field public customCutoffCurve CS.UnityEngine.AnimationCurve
---@field public lowpassResonanceQ number

---@type CS.UnityEngine.AudioLowPassFilter
CS.UnityEngine.AudioLowPassFilter = { }
---@return CS.UnityEngine.AudioLowPassFilter
function CS.UnityEngine.AudioLowPassFilter.New() end
return CS.UnityEngine.AudioLowPassFilter

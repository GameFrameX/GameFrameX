---@class CS.FairyEditor.Component.TextArea : CS.FairyGUI.GLabel

---@type CS.FairyEditor.Component.TextArea
CS.FairyEditor.Component.TextArea = { }
---@return CS.FairyEditor.Component.TextArea
function CS.FairyEditor.Component.TextArea.New() end
---@param xml CS.FairyGUI.Utils.XML
function CS.FairyEditor.Component.TextArea:ConstructFromXML(xml) end
return CS.FairyEditor.Component.TextArea

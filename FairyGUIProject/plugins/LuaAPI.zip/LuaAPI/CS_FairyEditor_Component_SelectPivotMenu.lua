---@class CS.FairyEditor.Component.SelectPivotMenu

---@type CS.FairyEditor.Component.SelectPivotMenu
CS.FairyEditor.Component.SelectPivotMenu = { }
---@return CS.FairyEditor.Component.SelectPivotMenu
function CS.FairyEditor.Component.SelectPivotMenu.New() end
---@return CS.FairyEditor.Component.SelectPivotMenu
function CS.FairyEditor.Component.SelectPivotMenu.GetInstance() end
---@param input1 CS.FairyGUI.GObject
---@param input2 CS.FairyGUI.GObject
---@param popupTarget CS.FairyGUI.GObject
function CS.FairyEditor.Component.SelectPivotMenu:Show(input1, input2, popupTarget) end
return CS.FairyEditor.Component.SelectPivotMenu

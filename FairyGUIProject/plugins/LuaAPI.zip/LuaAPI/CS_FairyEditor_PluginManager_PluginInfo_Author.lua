---@class CS.FairyEditor.PluginManager.PluginInfo.Author
---@field public name string

---@type CS.FairyEditor.PluginManager.PluginInfo.Author
CS.FairyEditor.PluginManager.PluginInfo.Author = { }
---@return CS.FairyEditor.PluginManager.PluginInfo.Author
function CS.FairyEditor.PluginManager.PluginInfo.Author.New() end
return CS.FairyEditor.PluginManager.PluginInfo.Author

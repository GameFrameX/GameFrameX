---@class CS.FairyEditor.AniData.FrameSprite
---@field public texture CS.FairyGUI.NTexture
---@field public frameIndex number
---@field public raw Byte[]

---@type CS.FairyEditor.AniData.FrameSprite
CS.FairyEditor.AniData.FrameSprite = { }
---@return CS.FairyEditor.AniData.FrameSprite
function CS.FairyEditor.AniData.FrameSprite.New() end
return CS.FairyEditor.AniData.FrameSprite

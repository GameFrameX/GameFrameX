---@class CS.FairyEditor.EaseTypeConst
---@field public easeType String[]
---@field public easeInOutType String[]

---@type CS.FairyEditor.EaseTypeConst
CS.FairyEditor.EaseTypeConst = { }
---@return number
---@param value string
function CS.FairyEditor.EaseTypeConst.Parse(value) end
return CS.FairyEditor.EaseTypeConst

---@class CS.FairyEditor.View.TransitionListView : CS.FairyGUI.GComponent

---@type CS.FairyEditor.View.TransitionListView
CS.FairyEditor.View.TransitionListView = { }
---@return CS.FairyEditor.View.TransitionListView
function CS.FairyEditor.View.TransitionListView.New() end
function CS.FairyEditor.View.TransitionListView:Refresh() end
return CS.FairyEditor.View.TransitionListView

---@class CS.FairyEditor.Framework.Gears.FGearLook : CS.FairyEditor.Framework.Gears.FGearBase_CS.FairyEditor.Framework.Gears.FGearLookValue

---@type CS.FairyEditor.Framework.Gears.FGearLook
CS.FairyEditor.Framework.Gears.FGearLook = { }
---@return CS.FairyEditor.Framework.Gears.FGearLook
---@param owner CS.FairyEditor.FObject
function CS.FairyEditor.Framework.Gears.FGearLook.New(owner) end
function CS.FairyEditor.Framework.Gears.FGearLook:Apply() end
function CS.FairyEditor.Framework.Gears.FGearLook:UpdateState() end
return CS.FairyEditor.Framework.Gears.FGearLook

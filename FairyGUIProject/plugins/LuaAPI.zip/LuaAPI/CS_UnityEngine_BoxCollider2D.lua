---@class CS.UnityEngine.BoxCollider2D : CS.UnityEngine.Collider2D
---@field public size CS.UnityEngine.Vector2
---@field public edgeRadius number
---@field public autoTiling boolean

---@type CS.UnityEngine.BoxCollider2D
CS.UnityEngine.BoxCollider2D = { }
---@return CS.UnityEngine.BoxCollider2D
function CS.UnityEngine.BoxCollider2D.New() end
return CS.UnityEngine.BoxCollider2D

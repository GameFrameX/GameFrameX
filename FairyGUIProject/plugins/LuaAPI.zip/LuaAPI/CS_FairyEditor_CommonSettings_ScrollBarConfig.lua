---@class CS.FairyEditor.CommonSettings.ScrollBarConfig
---@field public horizontal string
---@field public vertical string
---@field public defaultDisplay string

---@type CS.FairyEditor.CommonSettings.ScrollBarConfig
CS.FairyEditor.CommonSettings.ScrollBarConfig = { }
---@return CS.FairyEditor.CommonSettings.ScrollBarConfig
function CS.FairyEditor.CommonSettings.ScrollBarConfig.New() end
return CS.FairyEditor.CommonSettings.ScrollBarConfig

---@class CS.FairyEditor.FontUtil.FontInfo
---@field public family string
---@field public localeFamily string
---@field public file string
---@field public externalLoad boolean

---@type CS.FairyEditor.FontUtil.FontInfo
CS.FairyEditor.FontUtil.FontInfo = { }
---@return CS.FairyEditor.FontUtil.FontInfo
function CS.FairyEditor.FontUtil.FontInfo.New() end
return CS.FairyEditor.FontUtil.FontInfo

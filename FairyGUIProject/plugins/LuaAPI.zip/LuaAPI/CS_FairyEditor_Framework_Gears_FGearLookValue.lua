---@class CS.FairyEditor.Framework.Gears.FGearLookValue
---@field public alpha number
---@field public rotation number
---@field public grayed boolean
---@field public touchable boolean

---@type CS.FairyEditor.Framework.Gears.FGearLookValue
CS.FairyEditor.Framework.Gears.FGearLookValue = { }
---@return CS.FairyEditor.Framework.Gears.FGearLookValue
function CS.FairyEditor.Framework.Gears.FGearLookValue.New() end
return CS.FairyEditor.Framework.Gears.FGearLookValue

---@class CS.FairyEditor.Framework.Gears.FGearDisplay2 : CS.FairyEditor.Framework.Gears.FGearBase_CS.System.String
---@field public pages String[]

---@type CS.FairyEditor.Framework.Gears.FGearDisplay2
CS.FairyEditor.Framework.Gears.FGearDisplay2 = { }
---@return CS.FairyEditor.Framework.Gears.FGearDisplay2
---@param owner CS.FairyEditor.FObject
function CS.FairyEditor.Framework.Gears.FGearDisplay2.New(owner) end
---@return boolean
---@param connected boolean
function CS.FairyEditor.Framework.Gears.FGearDisplay2:Evaluate(connected) end
function CS.FairyEditor.Framework.Gears.FGearDisplay2:Apply() end
return CS.FairyEditor.Framework.Gears.FGearDisplay2

---@class CS.FairyGUI.TextField.CharPosition : CS.System.ValueType
---@field public charIndex number
---@field public lineIndex number
---@field public offsetX number
---@field public vertCount number
---@field public width number
---@field public imgIndex number

---@type CS.FairyGUI.TextField.CharPosition
CS.FairyGUI.TextField.CharPosition = { }

---@class CS.FairyEditor.FlipConst
---@field public NONE string
---@field public HZ string
---@field public VT string
---@field public BOTH string

---@type CS.FairyEditor.FlipConst
CS.FairyEditor.FlipConst = { }
---@return number
---@param str string
function CS.FairyEditor.FlipConst.Parse(str) end
return CS.FairyEditor.FlipConst

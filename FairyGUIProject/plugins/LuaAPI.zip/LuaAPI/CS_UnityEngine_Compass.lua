---@class CS.UnityEngine.Compass
---@field public magneticHeading number
---@field public trueHeading number
---@field public headingAccuracy number
---@field public rawVector CS.UnityEngine.Vector3
---@field public timestamp number
---@field public enabled boolean

---@type CS.UnityEngine.Compass
CS.UnityEngine.Compass = { }
---@return CS.UnityEngine.Compass
function CS.UnityEngine.Compass.New() end
return CS.UnityEngine.Compass

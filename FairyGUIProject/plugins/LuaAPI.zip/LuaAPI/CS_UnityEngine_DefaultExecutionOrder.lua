---@class CS.UnityEngine.DefaultExecutionOrder : CS.System.Attribute
---@field public order number

---@type CS.UnityEngine.DefaultExecutionOrder
CS.UnityEngine.DefaultExecutionOrder = { }
---@return CS.UnityEngine.DefaultExecutionOrder
---@param order number
function CS.UnityEngine.DefaultExecutionOrder.New(order) end
return CS.UnityEngine.DefaultExecutionOrder

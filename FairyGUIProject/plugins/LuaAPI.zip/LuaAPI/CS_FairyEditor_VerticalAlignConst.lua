---@class CS.FairyEditor.VerticalAlignConst
---@field public TOP string
---@field public MIDDLE string
---@field public BOTTOM string

---@type CS.FairyEditor.VerticalAlignConst
CS.FairyEditor.VerticalAlignConst = { }
---@return number
---@param str string
function CS.FairyEditor.VerticalAlignConst.Parse(str) end
---@return string
---@param t number
function CS.FairyEditor.VerticalAlignConst.ToString(t) end
return CS.FairyEditor.VerticalAlignConst

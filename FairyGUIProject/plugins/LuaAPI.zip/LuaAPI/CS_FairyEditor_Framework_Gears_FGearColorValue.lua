---@class CS.FairyEditor.Framework.Gears.FGearColorValue
---@field public color CS.UnityEngine.Color
---@field public strokeColor CS.UnityEngine.Color

---@type CS.FairyEditor.Framework.Gears.FGearColorValue
CS.FairyEditor.Framework.Gears.FGearColorValue = { }
---@return CS.FairyEditor.Framework.Gears.FGearColorValue
function CS.FairyEditor.Framework.Gears.FGearColorValue.New() end
return CS.FairyEditor.Framework.Gears.FGearColorValue

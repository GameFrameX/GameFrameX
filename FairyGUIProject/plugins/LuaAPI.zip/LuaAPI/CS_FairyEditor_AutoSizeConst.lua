---@class CS.FairyEditor.AutoSizeConst
---@field public NONE string
---@field public HEIGHT string
---@field public BOTH string
---@field public SHRINK string

---@type CS.FairyEditor.AutoSizeConst
CS.FairyEditor.AutoSizeConst = { }
---@return number
---@param str string
function CS.FairyEditor.AutoSizeConst.Parse(str) end
---@return string
---@param t number
function CS.FairyEditor.AutoSizeConst.ToString(t) end
return CS.FairyEditor.AutoSizeConst

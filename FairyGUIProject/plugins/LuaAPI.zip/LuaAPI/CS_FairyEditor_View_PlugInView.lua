---@class CS.FairyEditor.View.PlugInView : CS.FairyGUI.GComponent

---@type CS.FairyEditor.View.PlugInView
CS.FairyEditor.View.PlugInView = { }
---@return CS.FairyEditor.View.PlugInView
function CS.FairyEditor.View.PlugInView.New() end
return CS.FairyEditor.View.PlugInView

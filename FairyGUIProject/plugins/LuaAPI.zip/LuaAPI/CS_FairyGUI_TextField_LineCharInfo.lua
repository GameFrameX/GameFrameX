---@class CS.FairyGUI.TextField.LineCharInfo : CS.System.ValueType
---@field public width number
---@field public height number
---@field public baseline number

---@type CS.FairyGUI.TextField.LineCharInfo
CS.FairyGUI.TextField.LineCharInfo = { }

---@class CS.FairyEditor.Component.FontSizeInput : CS.FairyGUI.GLabel
---@field public value number
---@field public max number

---@type CS.FairyEditor.Component.FontSizeInput
CS.FairyEditor.Component.FontSizeInput = { }
---@return CS.FairyEditor.Component.FontSizeInput
function CS.FairyEditor.Component.FontSizeInput.New() end
---@param xml CS.FairyGUI.Utils.XML
function CS.FairyEditor.Component.FontSizeInput:ConstructFromXML(xml) end
return CS.FairyEditor.Component.FontSizeInput

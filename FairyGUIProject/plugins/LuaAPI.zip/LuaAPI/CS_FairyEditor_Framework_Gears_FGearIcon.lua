---@class CS.FairyEditor.Framework.Gears.FGearIcon : CS.FairyEditor.Framework.Gears.FGearBase_CS.System.String

---@type CS.FairyEditor.Framework.Gears.FGearIcon
CS.FairyEditor.Framework.Gears.FGearIcon = { }
---@return CS.FairyEditor.Framework.Gears.FGearIcon
---@param owner CS.FairyEditor.FObject
function CS.FairyEditor.Framework.Gears.FGearIcon.New(owner) end
function CS.FairyEditor.Framework.Gears.FGearIcon:Apply() end
function CS.FairyEditor.Framework.Gears.FGearIcon:UpdateState() end
return CS.FairyEditor.Framework.Gears.FGearIcon

---@class CS.FairyEditor.View.FavoritesView : CS.FairyGUI.GComponent

---@type CS.FairyEditor.View.FavoritesView
CS.FairyEditor.View.FavoritesView = { }
---@return CS.FairyEditor.View.FavoritesView
function CS.FairyEditor.View.FavoritesView.New() end
return CS.FairyEditor.View.FavoritesView

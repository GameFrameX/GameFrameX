---@class CS.FairyEditor.Framework.Gears.FGearFontSize : CS.FairyEditor.Framework.Gears.FGearBase_CS.System.Int32

---@type CS.FairyEditor.Framework.Gears.FGearFontSize
CS.FairyEditor.Framework.Gears.FGearFontSize = { }
---@return CS.FairyEditor.Framework.Gears.FGearFontSize
---@param owner CS.FairyEditor.FObject
function CS.FairyEditor.Framework.Gears.FGearFontSize.New(owner) end
function CS.FairyEditor.Framework.Gears.FGearFontSize:Apply() end
function CS.FairyEditor.Framework.Gears.FGearFontSize:UpdateState() end
return CS.FairyEditor.Framework.Gears.FGearFontSize

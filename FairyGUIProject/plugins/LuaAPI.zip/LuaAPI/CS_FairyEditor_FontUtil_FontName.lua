---@class CS.FairyEditor.FontUtil.FontName
---@field public family string
---@field public localeFamily string

---@type CS.FairyEditor.FontUtil.FontName
CS.FairyEditor.FontUtil.FontName = { }
---@return CS.FairyEditor.FontUtil.FontName
function CS.FairyEditor.FontUtil.FontName.New() end
return CS.FairyEditor.FontUtil.FontName

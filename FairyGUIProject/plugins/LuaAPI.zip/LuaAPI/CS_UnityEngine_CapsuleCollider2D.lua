---@class CS.UnityEngine.CapsuleCollider2D : CS.UnityEngine.Collider2D
---@field public size CS.UnityEngine.Vector2
---@field public direction number

---@type CS.UnityEngine.CapsuleCollider2D
CS.UnityEngine.CapsuleCollider2D = { }
---@return CS.UnityEngine.CapsuleCollider2D
function CS.UnityEngine.CapsuleCollider2D.New() end
return CS.UnityEngine.CapsuleCollider2D

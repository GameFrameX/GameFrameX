---@class CS.UnityEngine.BillboardRenderer : CS.UnityEngine.Renderer
---@field public billboard CS.UnityEngine.BillboardAsset

---@type CS.UnityEngine.BillboardRenderer
CS.UnityEngine.BillboardRenderer = { }
---@return CS.UnityEngine.BillboardRenderer
function CS.UnityEngine.BillboardRenderer.New() end
return CS.UnityEngine.BillboardRenderer

---@class CS.UnityEngine.ExecuteAlways : CS.System.Attribute

---@type CS.UnityEngine.ExecuteAlways
CS.UnityEngine.ExecuteAlways = { }
---@return CS.UnityEngine.ExecuteAlways
function CS.UnityEngine.ExecuteAlways.New() end
return CS.UnityEngine.ExecuteAlways

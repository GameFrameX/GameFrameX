---@class CS.FairyEditor.PublishHandler.ClassInfo
---@field public className string
---@field public superClassName string
---@field public resId string
---@field public resName string
---@field public res CS.FairyEditor.FPackageItem
---@field public members CS.System.Collections.Generic.List_CS.FairyEditor.PublishHandler.MemberInfo
---@field public references CS.System.Collections.Generic.List_CS.System.String

---@type CS.FairyEditor.PublishHandler.ClassInfo
CS.FairyEditor.PublishHandler.ClassInfo = { }
---@return CS.FairyEditor.PublishHandler.ClassInfo
function CS.FairyEditor.PublishHandler.ClassInfo.New() end
return CS.FairyEditor.PublishHandler.ClassInfo

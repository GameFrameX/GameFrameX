---@class CS.FairyEditor.Component.LinkButton : CS.FairyGUI.GButton

---@type CS.FairyEditor.Component.LinkButton
CS.FairyEditor.Component.LinkButton = { }
---@return CS.FairyEditor.Component.LinkButton
function CS.FairyEditor.Component.LinkButton.New() end
return CS.FairyEditor.Component.LinkButton

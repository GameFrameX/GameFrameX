---@class CS.UnityEngine.Camera.GateFitParameters : CS.System.ValueType
---@field public mode number
---@field public aspect number

---@type CS.UnityEngine.Camera.GateFitParameters
CS.UnityEngine.Camera.GateFitParameters = { }
---@return CS.UnityEngine.Camera.GateFitParameters
---@param mode number
---@param aspect number
function CS.UnityEngine.Camera.GateFitParameters.New(mode, aspect) end
return CS.UnityEngine.Camera.GateFitParameters

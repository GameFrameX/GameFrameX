---@class CS.FairyEditor.View.SearchView : CS.FairyGUI.GComponent

---@type CS.FairyEditor.View.SearchView
CS.FairyEditor.View.SearchView = { }
---@return CS.FairyEditor.View.SearchView
function CS.FairyEditor.View.SearchView.New() end
function CS.FairyEditor.View.SearchView:FillMenuTargets() end
return CS.FairyEditor.View.SearchView

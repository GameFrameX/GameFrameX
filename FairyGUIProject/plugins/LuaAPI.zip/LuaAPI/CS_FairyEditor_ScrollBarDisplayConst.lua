---@class CS.FairyEditor.ScrollBarDisplayConst
---@field public DEFAULT string
---@field public VISIBLE string
---@field public AUTO string
---@field public HIDDEN string

---@type CS.FairyEditor.ScrollBarDisplayConst
CS.FairyEditor.ScrollBarDisplayConst = { }

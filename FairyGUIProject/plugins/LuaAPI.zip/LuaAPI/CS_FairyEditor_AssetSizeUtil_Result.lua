---@class CS.FairyEditor.AssetSizeUtil.Result : CS.System.ValueType
---@field public width number
---@field public height number
---@field public type string
---@field public bitDepth number
---@field public colorType number

---@type CS.FairyEditor.AssetSizeUtil.Result
CS.FairyEditor.AssetSizeUtil.Result = { }

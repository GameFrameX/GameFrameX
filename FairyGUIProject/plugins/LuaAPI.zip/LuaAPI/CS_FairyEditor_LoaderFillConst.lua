---@class CS.FairyEditor.LoaderFillConst
---@field public NONE string
---@field public SCALE_SHOW_ALL string
---@field public SCALE_NO_BORDER string
---@field public SCALE_MATCH_HEIGHT string
---@field public SCALE_MATCH_WIDTH string
---@field public SCALE_FREE string

---@type CS.FairyEditor.LoaderFillConst
CS.FairyEditor.LoaderFillConst = { }

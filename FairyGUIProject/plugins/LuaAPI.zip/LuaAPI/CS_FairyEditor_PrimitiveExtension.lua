---@class CS.FairyEditor.PrimitiveExtension

---@type CS.FairyEditor.PrimitiveExtension
CS.FairyEditor.PrimitiveExtension = { }
---@return string
---@param fractionDigits number
function CS.FairyEditor.PrimitiveExtension.FormattedString(fractionDigits) end
return CS.FairyEditor.PrimitiveExtension

---@class CS.UnityEngine.AnchoredJoint2D : CS.UnityEngine.Joint2D
---@field public anchor CS.UnityEngine.Vector2
---@field public connectedAnchor CS.UnityEngine.Vector2
---@field public autoConfigureConnectedAnchor boolean

---@type CS.UnityEngine.AnchoredJoint2D
CS.UnityEngine.AnchoredJoint2D = { }
---@return CS.UnityEngine.AnchoredJoint2D
function CS.UnityEngine.AnchoredJoint2D.New() end
return CS.UnityEngine.AnchoredJoint2D

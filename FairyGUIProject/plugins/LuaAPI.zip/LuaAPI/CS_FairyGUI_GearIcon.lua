---@class CS.FairyGUI.GearIcon : CS.FairyGUI.GearBase

---@type CS.FairyGUI.GearIcon
CS.FairyGUI.GearIcon = { }
---@return CS.FairyGUI.GearIcon
---@param owner CS.FairyGUI.GObject
function CS.FairyGUI.GearIcon.New(owner) end
function CS.FairyGUI.GearIcon:Apply() end
function CS.FairyGUI.GearIcon:UpdateState() end
return CS.FairyGUI.GearIcon

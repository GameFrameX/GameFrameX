---@class CS.UnityEngine.FixedJoint : CS.UnityEngine.Joint

---@type CS.UnityEngine.FixedJoint
CS.UnityEngine.FixedJoint = { }
---@return CS.UnityEngine.FixedJoint
function CS.UnityEngine.FixedJoint.New() end
return CS.UnityEngine.FixedJoint

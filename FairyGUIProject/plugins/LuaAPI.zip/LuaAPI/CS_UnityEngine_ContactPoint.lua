---@class CS.UnityEngine.ContactPoint : CS.System.ValueType
---@field public point CS.UnityEngine.Vector3
---@field public normal CS.UnityEngine.Vector3
---@field public thisCollider CS.UnityEngine.Collider
---@field public otherCollider CS.UnityEngine.Collider
---@field public separation number

---@type CS.UnityEngine.ContactPoint
CS.UnityEngine.ContactPoint = { }
return CS.UnityEngine.ContactPoint

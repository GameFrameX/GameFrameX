---@class CS.UnityEngine.Coroutine : CS.UnityEngine.YieldInstruction

---@type CS.UnityEngine.Coroutine
CS.UnityEngine.Coroutine = { }

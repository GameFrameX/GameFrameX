---@class CS.FairyEditor.View.InspectorUpdateFlags
---@field public COMMON number
---@field public TRANSFORM number
---@field public GEAR number
---@field public RELATION number
---@field public GIZMO number
---@field public FlagsByName CS.System.Collections.Generic.Dictionary_CS.System.String_CS.System.Int32

---@type CS.FairyEditor.View.InspectorUpdateFlags
CS.FairyEditor.View.InspectorUpdateFlags = { }

---@class CS.FairyEditor.Framework.Gears.FGearText : CS.FairyEditor.Framework.Gears.FGearBase_CS.System.String

---@type CS.FairyEditor.Framework.Gears.FGearText
CS.FairyEditor.Framework.Gears.FGearText = { }
---@return CS.FairyEditor.Framework.Gears.FGearText
---@param owner CS.FairyEditor.FObject
function CS.FairyEditor.Framework.Gears.FGearText.New(owner) end
function CS.FairyEditor.Framework.Gears.FGearText:Apply() end
function CS.FairyEditor.Framework.Gears.FGearText:UpdateState() end
return CS.FairyEditor.Framework.Gears.FGearText

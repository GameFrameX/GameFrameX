---@class CS.FairyEditor.PublishHandler.MemberInfo
---@field public name string
---@field public varName string
---@field public type string
---@field public index number
---@field public group number
---@field public res CS.FairyEditor.FPackageItem

---@type CS.FairyEditor.PublishHandler.MemberInfo
CS.FairyEditor.PublishHandler.MemberInfo = { }
---@return CS.FairyEditor.PublishHandler.MemberInfo
function CS.FairyEditor.PublishHandler.MemberInfo.New() end
return CS.FairyEditor.PublishHandler.MemberInfo

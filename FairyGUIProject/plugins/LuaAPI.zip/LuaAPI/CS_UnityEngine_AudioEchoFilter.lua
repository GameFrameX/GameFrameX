---@class CS.UnityEngine.AudioEchoFilter : CS.UnityEngine.Behaviour
---@field public delay number
---@field public decayRatio number
---@field public dryMix number
---@field public wetMix number

---@type CS.UnityEngine.AudioEchoFilter
CS.UnityEngine.AudioEchoFilter = { }
---@return CS.UnityEngine.AudioEchoFilter
function CS.UnityEngine.AudioEchoFilter.New() end
return CS.UnityEngine.AudioEchoFilter

---@class CS.UnityEngine.ConstantForce : CS.UnityEngine.Behaviour
---@field public force CS.UnityEngine.Vector3
---@field public relativeForce CS.UnityEngine.Vector3
---@field public torque CS.UnityEngine.Vector3
---@field public relativeTorque CS.UnityEngine.Vector3

---@type CS.UnityEngine.ConstantForce
CS.UnityEngine.ConstantForce = { }
---@return CS.UnityEngine.ConstantForce
function CS.UnityEngine.ConstantForce.New() end
return CS.UnityEngine.ConstantForce

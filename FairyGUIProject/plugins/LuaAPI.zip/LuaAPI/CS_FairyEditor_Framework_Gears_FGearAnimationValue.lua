---@class CS.FairyEditor.Framework.Gears.FGearAnimationValue
---@field public playing boolean
---@field public frame number

---@type CS.FairyEditor.Framework.Gears.FGearAnimationValue
CS.FairyEditor.Framework.Gears.FGearAnimationValue = { }
---@return CS.FairyEditor.Framework.Gears.FGearAnimationValue
function CS.FairyEditor.Framework.Gears.FGearAnimationValue.New() end
return CS.FairyEditor.Framework.Gears.FGearAnimationValue

---@class CS.FairyEditor.Framework.Gears.FGearAnimation : CS.FairyEditor.Framework.Gears.FGearBase_CS.FairyEditor.Framework.Gears.FGearAnimationValue

---@type CS.FairyEditor.Framework.Gears.FGearAnimation
CS.FairyEditor.Framework.Gears.FGearAnimation = { }
---@return CS.FairyEditor.Framework.Gears.FGearAnimation
---@param owner CS.FairyEditor.FObject
function CS.FairyEditor.Framework.Gears.FGearAnimation.New(owner) end
function CS.FairyEditor.Framework.Gears.FGearAnimation:Apply() end
function CS.FairyEditor.Framework.Gears.FGearAnimation:UpdateState() end
return CS.FairyEditor.Framework.Gears.FGearAnimation

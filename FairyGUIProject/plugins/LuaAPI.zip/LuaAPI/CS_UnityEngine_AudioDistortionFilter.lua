---@class CS.UnityEngine.AudioDistortionFilter : CS.UnityEngine.Behaviour
---@field public distortionLevel number

---@type CS.UnityEngine.AudioDistortionFilter
CS.UnityEngine.AudioDistortionFilter = { }
---@return CS.UnityEngine.AudioDistortionFilter
function CS.UnityEngine.AudioDistortionFilter.New() end
return CS.UnityEngine.AudioDistortionFilter

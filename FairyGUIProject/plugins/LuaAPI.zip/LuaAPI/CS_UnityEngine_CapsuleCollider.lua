---@class CS.UnityEngine.CapsuleCollider : CS.UnityEngine.Collider
---@field public center CS.UnityEngine.Vector3
---@field public radius number
---@field public height number
---@field public direction number

---@type CS.UnityEngine.CapsuleCollider
CS.UnityEngine.CapsuleCollider = { }
---@return CS.UnityEngine.CapsuleCollider
function CS.UnityEngine.CapsuleCollider.New() end
return CS.UnityEngine.CapsuleCollider

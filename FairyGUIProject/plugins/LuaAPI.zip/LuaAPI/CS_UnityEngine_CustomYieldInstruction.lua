---@class CS.UnityEngine.CustomYieldInstruction
---@field public keepWaiting boolean
---@field public Current CS.System.Object

---@type CS.UnityEngine.CustomYieldInstruction
CS.UnityEngine.CustomYieldInstruction = { }
---@return boolean
function CS.UnityEngine.CustomYieldInstruction:MoveNext() end
function CS.UnityEngine.CustomYieldInstruction:Reset() end
return CS.UnityEngine.CustomYieldInstruction

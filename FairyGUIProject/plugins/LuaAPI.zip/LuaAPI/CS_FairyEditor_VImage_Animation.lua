---@class CS.FairyEditor.VImage.Animation : CS.System.ValueType
---@field public frames VImage[]
---@field public frameDelays Int32[]
---@field public loopDelay number

---@type CS.FairyEditor.VImage.Animation
CS.FairyEditor.VImage.Animation = { }

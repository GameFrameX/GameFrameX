---@class CS.UnityEngine.AssetBundleRecompressOperation : CS.UnityEngine.AsyncOperation
---@field public humanReadableResult string
---@field public inputPath string
---@field public outputPath string
---@field public result number
---@field public success boolean

---@type CS.UnityEngine.AssetBundleRecompressOperation
CS.UnityEngine.AssetBundleRecompressOperation = { }
---@return CS.UnityEngine.AssetBundleRecompressOperation
function CS.UnityEngine.AssetBundleRecompressOperation.New() end
return CS.UnityEngine.AssetBundleRecompressOperation

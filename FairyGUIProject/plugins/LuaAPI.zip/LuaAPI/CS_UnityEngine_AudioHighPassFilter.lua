---@class CS.UnityEngine.AudioHighPassFilter : CS.UnityEngine.Behaviour
---@field public cutoffFrequency number
---@field public highpassResonanceQ number

---@type CS.UnityEngine.AudioHighPassFilter
CS.UnityEngine.AudioHighPassFilter = { }
---@return CS.UnityEngine.AudioHighPassFilter
function CS.UnityEngine.AudioHighPassFilter.New() end
return CS.UnityEngine.AudioHighPassFilter

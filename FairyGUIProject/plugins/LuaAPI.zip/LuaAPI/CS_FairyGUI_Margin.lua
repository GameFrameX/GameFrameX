---@class CS.FairyGUI.Margin : CS.System.ValueType
---@field public left number
---@field public right number
---@field public top number
---@field public bottom number

---@type CS.FairyGUI.Margin
CS.FairyGUI.Margin = { }

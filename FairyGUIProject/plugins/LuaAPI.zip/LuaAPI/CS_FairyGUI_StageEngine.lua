---@class CS.FairyGUI.StageEngine : CS.UnityEngine.MonoBehaviour
---@field public ObjectsOnStage number
---@field public GraphicsOnStage number
---@field public beingQuit boolean

---@type CS.FairyGUI.StageEngine
CS.FairyGUI.StageEngine = { }
---@return CS.FairyGUI.StageEngine
function CS.FairyGUI.StageEngine.New() end
return CS.FairyGUI.StageEngine

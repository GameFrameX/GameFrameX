---@class CS.FairyGUI.NGraphics.VertexMatrix
---@field public cameraPos CS.UnityEngine.Vector3
---@field public matrix CS.UnityEngine.Matrix4x4

---@type CS.FairyGUI.NGraphics.VertexMatrix
CS.FairyGUI.NGraphics.VertexMatrix = { }
---@return CS.FairyGUI.NGraphics.VertexMatrix
function CS.FairyGUI.NGraphics.VertexMatrix.New() end
return CS.FairyGUI.NGraphics.VertexMatrix

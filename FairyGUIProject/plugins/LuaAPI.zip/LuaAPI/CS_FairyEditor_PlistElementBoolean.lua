---@class CS.FairyEditor.PlistElementBoolean : CS.FairyEditor.PlistElement
---@field public value boolean

---@type CS.FairyEditor.PlistElementBoolean
CS.FairyEditor.PlistElementBoolean = { }
---@return CS.FairyEditor.PlistElementBoolean
---@param v boolean
function CS.FairyEditor.PlistElementBoolean.New(v) end
return CS.FairyEditor.PlistElementBoolean

---@class CS.UnityEngine.AccelerationEvent : CS.System.ValueType
---@field public acceleration CS.UnityEngine.Vector3
---@field public deltaTime number

---@type CS.UnityEngine.AccelerationEvent
CS.UnityEngine.AccelerationEvent = { }
return CS.UnityEngine.AccelerationEvent

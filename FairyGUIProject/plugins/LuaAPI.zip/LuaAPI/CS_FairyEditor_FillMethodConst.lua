---@class CS.FairyEditor.FillMethodConst

---@type CS.FairyEditor.FillMethodConst
CS.FairyEditor.FillMethodConst = { }
---@return number
---@param str string
function CS.FairyEditor.FillMethodConst.Parse(str) end
return CS.FairyEditor.FillMethodConst

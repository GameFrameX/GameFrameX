---@class CS.UnityEngine.AssetBundleRequest : CS.UnityEngine.AsyncOperation
---@field public asset CS.UnityEngine.Object
---@field public allAssets Object[]

---@type CS.UnityEngine.AssetBundleRequest
CS.UnityEngine.AssetBundleRequest = { }
---@return CS.UnityEngine.AssetBundleRequest
function CS.UnityEngine.AssetBundleRequest.New() end
return CS.UnityEngine.AssetBundleRequest

---@class CS.UnityEngine.AssetBundleCreateRequest : CS.UnityEngine.AsyncOperation
---@field public assetBundle CS.UnityEngine.AssetBundle

---@type CS.UnityEngine.AssetBundleCreateRequest
CS.UnityEngine.AssetBundleCreateRequest = { }
---@return CS.UnityEngine.AssetBundleCreateRequest
function CS.UnityEngine.AssetBundleCreateRequest.New() end
return CS.UnityEngine.AssetBundleCreateRequest

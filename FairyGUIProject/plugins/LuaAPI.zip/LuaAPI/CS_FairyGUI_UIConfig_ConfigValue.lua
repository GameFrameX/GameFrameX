---@class CS.FairyGUI.UIConfig.ConfigValue
---@field public valid boolean
---@field public s string
---@field public i number
---@field public f number
---@field public b boolean
---@field public c CS.UnityEngine.Color

---@type CS.FairyGUI.UIConfig.ConfigValue
CS.FairyGUI.UIConfig.ConfigValue = { }
---@return CS.FairyGUI.UIConfig.ConfigValue
function CS.FairyGUI.UIConfig.ConfigValue.New() end
function CS.FairyGUI.UIConfig.ConfigValue:Reset() end
return CS.FairyGUI.UIConfig.ConfigValue

---@class CS.FairyEditor.Framework.Gears.FGearXYValue
---@field public x number
---@field public y number
---@field public px number
---@field public py number

---@type CS.FairyEditor.Framework.Gears.FGearXYValue
CS.FairyEditor.Framework.Gears.FGearXYValue = { }
---@return CS.FairyEditor.Framework.Gears.FGearXYValue
function CS.FairyEditor.Framework.Gears.FGearXYValue.New() end
return CS.FairyEditor.Framework.Gears.FGearXYValue

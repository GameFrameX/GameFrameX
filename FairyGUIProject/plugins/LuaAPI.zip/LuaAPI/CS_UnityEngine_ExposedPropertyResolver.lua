---@class CS.UnityEngine.ExposedPropertyResolver : CS.System.ValueType

---@type CS.UnityEngine.ExposedPropertyResolver
CS.UnityEngine.ExposedPropertyResolver = { }

---@class CS.FairyEditor.AlignConst
---@field public LEFT string
---@field public CENTER string
---@field public RIGHT string

---@type CS.FairyEditor.AlignConst
CS.FairyEditor.AlignConst = { }
---@return number
---@param str string
function CS.FairyEditor.AlignConst.Parse(str) end
---@return string
---@param t number
function CS.FairyEditor.AlignConst.ToString(t) end
return CS.FairyEditor.AlignConst

---@class CS.FairyEditor.PlistElementInteger : CS.FairyEditor.PlistElement
---@field public value number

---@type CS.FairyEditor.PlistElementInteger
CS.FairyEditor.PlistElementInteger = { }
---@return CS.FairyEditor.PlistElementInteger
---@param v number
function CS.FairyEditor.PlistElementInteger.New(v) end
return CS.FairyEditor.PlistElementInteger

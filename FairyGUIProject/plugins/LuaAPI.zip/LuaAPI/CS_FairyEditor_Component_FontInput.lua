---@class CS.FairyEditor.Component.FontInput : CS.FairyGUI.GLabel

---@type CS.FairyEditor.Component.FontInput
CS.FairyEditor.Component.FontInput = { }
---@return CS.FairyEditor.Component.FontInput
function CS.FairyEditor.Component.FontInput.New() end
---@param xml CS.FairyGUI.Utils.XML
function CS.FairyEditor.Component.FontInput:ConstructFromXML(xml) end
return CS.FairyEditor.Component.FontInput

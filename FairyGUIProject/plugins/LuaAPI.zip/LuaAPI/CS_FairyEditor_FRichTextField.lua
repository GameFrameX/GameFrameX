---@class CS.FairyEditor.FRichTextField : CS.FairyEditor.FTextField

---@type CS.FairyEditor.FRichTextField
CS.FairyEditor.FRichTextField = { }
---@return CS.FairyEditor.FRichTextField
---@param flags number
function CS.FairyEditor.FRichTextField.New(flags) end
return CS.FairyEditor.FRichTextField

---@class CS.FairyEditor.AdaptationSettings.DeviceInfo : CS.System.ValueType
---@field public name string
---@field public resolutionX number
---@field public resolutionY number

---@type CS.FairyEditor.AdaptationSettings.DeviceInfo
CS.FairyEditor.AdaptationSettings.DeviceInfo = { }

---@class CS.FairyEditor.LoaderExtension : CS.FairyGUI.GLoader

---@type CS.FairyEditor.LoaderExtension
CS.FairyEditor.LoaderExtension = { }
---@return CS.FairyEditor.LoaderExtension
function CS.FairyEditor.LoaderExtension.New() end
return CS.FairyEditor.LoaderExtension

---@class CS.UnityEngine.DistanceJoint2D : CS.UnityEngine.AnchoredJoint2D
---@field public autoConfigureDistance boolean
---@field public distance number
---@field public maxDistanceOnly boolean

---@type CS.UnityEngine.DistanceJoint2D
CS.UnityEngine.DistanceJoint2D = { }
---@return CS.UnityEngine.DistanceJoint2D
function CS.UnityEngine.DistanceJoint2D.New() end
return CS.UnityEngine.DistanceJoint2D

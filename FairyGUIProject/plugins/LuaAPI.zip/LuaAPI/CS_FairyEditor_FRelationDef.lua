---@class CS.FairyEditor.FRelationDef
---@field public affectBySelfSizeChanged boolean
---@field public percent boolean
---@field public type number

---@type CS.FairyEditor.FRelationDef
CS.FairyEditor.FRelationDef = { }
---@return CS.FairyEditor.FRelationDef
function CS.FairyEditor.FRelationDef.New() end
---@return string
function CS.FairyEditor.FRelationDef:ToString() end
return CS.FairyEditor.FRelationDef

---@class CS.UnityEngine.CircleCollider2D : CS.UnityEngine.Collider2D
---@field public radius number

---@type CS.UnityEngine.CircleCollider2D
CS.UnityEngine.CircleCollider2D = { }
---@return CS.UnityEngine.CircleCollider2D
function CS.UnityEngine.CircleCollider2D.New() end
return CS.UnityEngine.CircleCollider2D

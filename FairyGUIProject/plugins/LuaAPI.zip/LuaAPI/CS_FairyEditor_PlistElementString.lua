---@class CS.FairyEditor.PlistElementString : CS.FairyEditor.PlistElement
---@field public value string

---@type CS.FairyEditor.PlistElementString
CS.FairyEditor.PlistElementString = { }
---@return CS.FairyEditor.PlistElementString
---@param v string
function CS.FairyEditor.PlistElementString.New(v) end
return CS.FairyEditor.PlistElementString

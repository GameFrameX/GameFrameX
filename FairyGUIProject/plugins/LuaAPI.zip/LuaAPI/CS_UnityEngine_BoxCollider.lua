---@class CS.UnityEngine.BoxCollider : CS.UnityEngine.Collider
---@field public center CS.UnityEngine.Vector3
---@field public size CS.UnityEngine.Vector3

---@type CS.UnityEngine.BoxCollider
CS.UnityEngine.BoxCollider = { }
---@return CS.UnityEngine.BoxCollider
function CS.UnityEngine.BoxCollider.New() end
return CS.UnityEngine.BoxCollider

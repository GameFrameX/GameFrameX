---@class CS.UnityEngine.ClothSkinningCoefficient : CS.System.ValueType
---@field public maxDistance number
---@field public collisionSphereDistance number

---@type CS.UnityEngine.ClothSkinningCoefficient
CS.UnityEngine.ClothSkinningCoefficient = { }

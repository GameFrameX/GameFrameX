---@class CS.FairyGUI.MovieClip.Frame
---@field public texture CS.FairyGUI.NTexture
---@field public addDelay number

---@type CS.FairyGUI.MovieClip.Frame
CS.FairyGUI.MovieClip.Frame = { }
---@return CS.FairyGUI.MovieClip.Frame
function CS.FairyGUI.MovieClip.Frame.New() end
return CS.FairyGUI.MovieClip.Frame
